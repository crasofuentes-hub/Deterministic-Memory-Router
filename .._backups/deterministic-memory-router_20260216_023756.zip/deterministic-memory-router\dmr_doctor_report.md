# DMR Doctor Report

```json
{
  "summary": {
    "dmr_version": "2026.0.2",
    "timestamp_utc": "2026-02-16T10:29:22Z",
    "ok": true,
    "report_signature": "419ba73381f166a6"
  },
  "environment": {
    "timestamp_utc": "2026-02-16T10:29:18Z",
    "os": "Windows 11 (AMD64)",
    "python": "3.14.0",
    "redis_url": "redis://localhost:6379/0",
    "cold_sqlite": "C:\\repos\\deterministic-memory-router\\doctor_cold.sqlite3",
    "faiss_dir": "./dmr_faiss_hot",
    "vector_dim": 20,
    "numpy": "2.4.2",
    "faiss": "1.13.2"
  },
  "checks": [
    {
      "name": "redis_hot_available",
      "ok": true,
      "details": {
        "error": "Error 10061 connecting to localhost:6379. No connection could be made because the target machine actively refused it.",
        "mode": "degraded_no_redis"
      }
    },
    {
      "name": "strict_determinism_pre",
      "ok": true,
      "details": {
        "sig1": "520a7be9bb9e78af",
        "sig2": "520a7be9bb9e78af"
      }
    },
    {
      "name": "no_saturation_contract",
      "ok": true,
      "details": {
        "k_final": 5,
        "returned_k": 5,
        "max_chars": 800,
        "returned_chars": 150
      }
    },
    {
      "name": "cold_storage_consultable",
      "ok": true,
      "details": {
        "cold_hits": 5
      }
    }
  ]
}
```
